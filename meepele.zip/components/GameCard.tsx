import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { BrandIcon } from "@/components/BrandIcon";
import { GameCoverImage } from "@/components/GameCoverImage";
import { getPrimaryGameTags } from "@/lib/gameDisplayTags";
import { getEffectiveRatingScore, type CatalogGame } from "@/lib/catalog";

type GameCardProps = {
  game: CatalogGame;
  compact?: boolean;
  poster?: boolean;
  dateMode?: "absolute" | "relativeRecent";
};

export function GameCard({ game, compact, poster, dateMode = "absolute" }: GameCardProps) {
  const primaryTags = getPrimaryGameTags(game, 2);
  const ratingScore = getEffectiveRatingScore(game);

  if (poster) {
    return (
      <article className="group min-w-0">
        <Link href={`/juegos/${game.slug}`} prefetch className="block" aria-label={`Abrir ficha de ${game.title}`}>
          <div className="relative overflow-hidden rounded-md border border-walnut/15 bg-walnut/10 shadow-sm transition group-hover:-translate-y-0.5 group-hover:border-ember/45 group-hover:shadow-soft">
            <GameCoverImage
              {...game}
              gameTitle={game.title}
              variant="card"
              showPlaceholderLabel={false}
              className="rounded-none"
            />
            <span className="absolute bottom-2 right-2 inline-flex items-center gap-1 rounded-md bg-wood/90 px-2 py-1 text-sm font-black leading-none text-white shadow-sm">
              <BrandIcon name="star" size={15} />
              {typeof ratingScore === "number" ? ratingScore.toFixed(1) : "MT"}
            </span>
          </div>
          <h3 className="mt-2 truncate text-sm font-extrabold leading-5 text-wood">{game.title}</h3>
          <p className="mt-1 truncate text-xs font-semibold leading-4 text-walnut/65">
            {[game.playersLabel, game.playtime, game.complexity].filter(Boolean).join(" · ")}
          </p>
        </Link>
      </article>
    );
  }

  if (compact) {
    return (
      <article className="tavern-card h-full min-h-[144px] overflow-hidden transition hover:-translate-y-0.5 hover:border-ember/45 xl:h-[150px] xl:min-h-[150px]">
        <Link
          href={`/juegos/${game.slug}`}
          prefetch
          className="grid h-full min-h-[144px] grid-cols-[88px_minmax(0,1fr)] items-center gap-4 p-3 touch-manipulation cursor-pointer sm:p-4 xl:h-[150px] xl:min-h-[150px]"
          aria-label={`Abrir ficha de ${game.title}`}
        >
          <GameCoverImage
            {...game}
            gameTitle={game.title}
            variant="ranking"
            showPlaceholderLabel={false}
            className="self-start"
          />
          <div className="min-w-0 py-1">
            <div className="flex flex-wrap gap-2">
              {primaryTags.map((tag) => (
                <span key={tag} className="tavern-pill">
                  {tag}
                </span>
              ))}
            </div>
            <h3 className="font-display mt-3 line-clamp-2 text-lg font-bold leading-tight text-wood">{game.title}</h3>
            {game.publishedAt ? (
              <p className="mt-1.5 inline-flex w-fit rounded-[4px] border border-ember/18 bg-ember/8 px-2 py-0.5 text-[11px] font-black uppercase tracking-[0.11em] text-ember">
                {formatAddedDate(game.publishedAt, dateMode)}
              </p>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold leading-5 text-walnut/70">
              <span className="inline-flex items-center gap-1.5">
                <BrandIcon name="users" size={16} />
                {game.playersLabel || "Jugadores pendiente"}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <BrandIcon name="clock" size={16} />
                {game.playtime || "Duración pendiente"}
              </span>
            </div>
          </div>
        </Link>
      </article>
    );
  }

  return (
    <article className="tavern-card overflow-hidden transition hover:-translate-y-0.5 hover:border-ember/45">
      <Link
        href={`/juegos/${game.slug}`}
        prefetch
        className="block touch-manipulation cursor-pointer"
        aria-label={`Abrir ficha de ${game.title}`}
      >
        <GameCoverImage {...game} gameTitle={game.title} variant="card" />
        <div className="p-4 sm:p-5">
          <div className="mb-3 flex items-start justify-between gap-3">
            <div className="flex flex-wrap gap-2">
              {primaryTags.map((tag) => (
                <span
                  key={tag}
                  className="tavern-pill"
                >
                  {tag}
                </span>
              ))}
            </div>
            {typeof ratingScore === "number" ? (
              <span className="rating-chip shrink-0">
                <BrandIcon name="star" size={14} />
                {ratingScore.toFixed(1)}
              </span>
            ) : null}
          </div>
          <h3 className="font-display text-xl font-bold leading-tight text-wood">{game.title}</h3>
          <p className="mt-3 line-clamp-3 text-sm leading-6 text-walnut/80">{game.reviewSummary}</p>
          <div className="mt-4 flex flex-wrap gap-x-3 gap-y-2 text-xs font-semibold leading-5 text-walnut/70">
            <span className="inline-flex items-center gap-1.5">
              <BrandIcon name="users" size={16} />
              {game.playersLabel || "Jugadores pendiente"}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <BrandIcon name="clock" size={16} />
              {game.playtime || "Duración pendiente"}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <BrandIcon name="gauge" size={16} />
              {game.complexity || "Dificultad pendiente"}
            </span>
          </div>
          <div className="mt-5 flex items-center justify-between gap-3 border-t border-walnut/10 pt-4">
            <span className="text-xs font-bold uppercase tracking-[0.12em] text-walnut/55">
              {game.categories[0] || "Juego de mesa"}
            </span>
            <span className="inline-flex items-center gap-1.5 text-sm font-extrabold text-ember">
              Ver ficha
              <ChevronRight size={16} strokeWidth={2.2} />
            </span>
          </div>
        </div>
      </Link>
    </article>
  );
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(new Date(value));
}

function formatAddedDate(value: string, mode: GameCardProps["dateMode"]) {
  if (mode !== "relativeRecent") {
    return formatDate(value);
  }

  const addedAt = new Date(value);
  const today = startOfDay(new Date());
  const addedDay = startOfDay(addedAt);
  const daysAgo = Math.floor((today.getTime() - addedDay.getTime()) / 86_400_000);

  if (daysAgo <= 0) {
    return "Añadido hoy";
  }

  if (daysAgo <= 3) {
    return `Añadido hace ${daysAgo} ${daysAgo === 1 ? "día" : "días"}`;
  }

  return `Añadido el ${formatDate(value)}`;
}

function startOfDay(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}
