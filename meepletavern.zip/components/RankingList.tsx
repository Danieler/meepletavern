import Link from "next/link";
import { GameCoverImage } from "@/components/GameCoverImage";
import type { CatalogGame } from "@/lib/catalog";
import { getPrimaryGameTags } from "@/lib/gameDisplayTags";

export function RankingList({ games }: { games: CatalogGame[] }) {
  return (
    <ol className="divide-y divide-ink/10 overflow-hidden rounded-md border border-ink/10 bg-white shadow-soft">
      {games.map((game, index) => (
        <li key={game.slug}>
          <Link
            href={`/juegos/${game.slug}`}
            className="grid gap-4 p-4 transition hover:bg-parchment/60 sm:grid-cols-[54px_70px_1fr] sm:items-center touch-manipulation cursor-pointer"
            aria-label={`Abrir ficha de ${game.title}`}
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-md bg-ink text-lg font-black text-white">
              {index + 1}
            </span>
            <GameCoverImage {...game} gameTitle={game.title} variant="ranking" showPlaceholderLabel={false} />
            <span>
              <span className="block text-lg font-black text-ink">{game.title}</span>
              <span className="mt-1 block text-sm text-ink/60">
                {[getPrimaryGameTags(game, 2).join(" · "), game.playtime, game.complexity].filter(Boolean).join(" · ")}
              </span>
            </span>
          </Link>
        </li>
      ))}
    </ol>
  );
}
